// Name: 
// Quarter, Year: 
// Lab:
//
// This file is to be modified by the student.
// main.cpp
////////////////////////////////////////////////////////////
#include "object.h"
#include "quadtree.h"
#include <algorithm>
#include <GL/glut.h>

const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 800;
const double VIEW_LEFT = 0.0;
const double VIEW_RIGHT = WINDOW_WIDTH;
const double VIEW_TOP = 0.0;
const double VIEW_BOTTOM = WINDOW_HEIGHT;
const int DEPTH_LIMIT = 5;
const int LIST_LIMIT = 1;

QuadTree quadtree(Rect2D(Point2D(VIEW_LEFT, VIEW_TOP), VIEW_RIGHT - VIEW_LEFT, VIEW_BOTTOM - VIEW_TOP), DEPTH_LIMIT, LIST_LIMIT);

int currentTime = 0;
int previousTime = 0;

void GLrender();
void GLupdate();

//Initializes OpenGL attributes
void GLInit(int* argc, char** argv)
{
	glutInit(argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
	glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
	glutCreateWindow("Lab 2 - <Insert Name Here>");
	glutDisplayFunc(GLrender);
	glutIdleFunc(GLupdate);
	glClearColor(1.0f, 1.0f, 1.0f, 0.0f);
	gluOrtho2D(VIEW_LEFT, VIEW_RIGHT, VIEW_BOTTOM, VIEW_TOP);
}

int main(int argc, char** argv)
{
	GLInit(&argc, argv);
	glutMainLoop();
	return 0;
}

void GLupdate()
{
	const int FRAME_RATE = 25;

	glutPostRedisplay();

	//sleep is not effective in capturing constant time between frames because sleep
	//doesn't consider the time it takes for context-switching. However, this reduces
	//the cpu-usage. If accurate time frames are desire, use a time accumulator
	currentTime = glutGet(GLUT_ELAPSED_TIME);
	int diffTime = currentTime - previousTime;
	previousTime = currentTime;
	usleep(1000 * std::max(FRAME_RATE - diffTime, 0));
}

void GLrender()
{
	glClear(GL_COLOR_BUFFER_BIT);

	glFlush();	
	glutSwapBuffers();
}
