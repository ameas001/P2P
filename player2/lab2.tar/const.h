//const.h
//
//You do not need to modify this file
//C.P
////////////////////////////////////////////////////////////
#ifndef __CONST_H__
#define __CONST_H__

const double PI = 3.14159265;
const double EPSILON = 0.015625; //2^-6

#endif
