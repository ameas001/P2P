// Name: 
// Quarter, Year: 
// Lab:
//
// This file is to be modified by the student.
// quadtree.cpp
////////////////////////////////////////////////////////////
#include "quadtree.h"

QuadTreeNode::QuadTreeNode(const Rect2D & space)
	: nodeType(QUAD_TREE_LEAF), space(space), objects(), topLeft(NULL), topRight(NULL), bottomLeft(NULL), bottomRight(NULL)
{}

void QuadTreeNode::insert(const Line2D & value, int currentDepth, int depthLimit, int listLimit)
{
	if (nodeType == QUAD_TREE_PARENT)
	{
	}
	else //(nodeType == QUAD_TREE_LEAF)
	{
	}
}

void QuadTreeNode::query(const Point2D & p, std::vector<Line2D> & ret) const
{
	if (nodeType == QUAD_TREE_PARENT)
	{
	}
	else //if (nodeType == QUAD_TREE_LEAF)
	{
	}
}

//Recursively deletes the QuadTree
void QuadTreeNode::dealloc()
{
	if (topLeft)
	{
		topLeft->dealloc();
		delete topLeft;
	}
	if (topRight)
	{
		topRight->dealloc();
		delete topRight;
	}
	if (bottomLeft)
	{
		bottomLeft->dealloc();
		delete bottomLeft;
	}
	if (bottomRight)
	{
		bottomRight->dealloc();
		delete bottomRight;
	}
}

void QuadTreeNode::render() const
{
	if (nodeType == QUAD_TREE_PARENT)
	{
	}
	else //if(nodeType == QUAD_TREE_LEAF)
	{
	}
}

QuadTree::QuadTree(const Rect2D & space, int dlim, int llim)
	: root(new QuadTreeNode(space)), depthLimit(dlim), listLimit(llim)
{}

QuadTree::~QuadTree()
{
	root->dealloc();
}

void QuadTree::insert(const Line2D & value)
{
	root->insert(value, 1, depthLimit, listLimit);
}

std::vector<Line2D> QuadTree::query(const Point2D & p) const
{
	std::vector<Line2D> ret;
	root->query(p, ret);
	return ret;
}

void QuadTree::render() const
{
	root->render();
}
